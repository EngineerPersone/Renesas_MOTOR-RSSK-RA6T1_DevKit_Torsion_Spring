/*
 * mtr_main.c
 *
 *  Created on: Jul 28, 2026
 *      Author: danie
 */

/***********************************************************************************************************************
 * Includes <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include <stdint.h>
#include <math.h>
#include "mtr_main.h"
#include "hal_data.h"

#ifndef PI
#define PI 3.14159265358979323846f
#endif

#define MOTOR_POLE_PAIRS    (2.0f)

/***********************************************************************************************************************
 * Global variables
 ***********************************************************************************************************************/
float g_f4_speed_ref = 0;
float g_f_position_ref = 0;
uint8_t g_u1_motor_status; /* Motor status */
uint8_t com_u1_sw_userif; /* User interface switch */
uint8_t g_u1_sw_userif; /* User interface switch */
uint8_t com_u1_mode_system; /* System mode */
uint8_t g_u1_mode_system; /* System mode */
uint16_t g_u2_max_speed_rpm;
uint8_t g_u1_stop_req;
uint16_t g_u2_chk_error;
uint16_t g_u2_vr1_ad;
uint16_t g_u2_conf_hw;
uint16_t g_u2_conf_sw;
uint16_t g_u2_conf_tool;
uint8_t g_u1_reset_req; /* Reset request flag */
uint8_t g_u1_sw_cnt; /* Counter to remove chattering */
uint8_t g_u1_loop_mode;
motor_cfg_t g_user_motor_cfg;
motor_encoder_extended_cfg_t g_user_motor_encoder_extended_cfg;
motor_speed_cfg_t g_user_motor_speed_cfg;
motor_speed_extended_cfg_t g_user_motor_speed_extended_cfg;
motor_position_cfg_t g_user_motor_position_cfg;
motor_position_extended_cfg_t g_user_motor_position_extended_cfg;
motor_current_cfg_t g_user_motor_current_cfg;
motor_current_extended_cfg_t g_user_motor_current_extended_cfg;
motor_angle_cfg_t g_user_motor_angle_cfg;
motor_sense_encoder_extended_cfg_t g_user_motor_sense_encoder_extended_cfg;
motor_driver_cfg_t g_user_motor_driver_cfg;
motor_driver_extended_cfg_t g_user_motor_driver_extended_cfg;
motor_current_motor_parameter_t g_user_motor_current_motor_parameter;
motor_current_design_parameter_t g_user_motor_current_design_parameter;

//spring declarations
static float continuous_angle_mech = 0.0f;
static float previous_raw_angle = 0.0f;
static bool first_run = true;

float Iq = 0.0f;
const float max_current = 5.0f;
float spring_constant = 0.1f;
float raw_angle = 0.0f;
float actual_iq_ref = 0.0f;

// PID Control Parameters
float Kp = 0.2f;            // Spring stiffness (A / rad)
float Ki = 0.1f;           // Integral gain (A / (rad * s))
float Kd = 0.001f;          // Damping factor (A * s / rad)

const float SAMPLE_TIME_S = 0.0001f;
static float error_integral = 0.0f;

static void motor_fsp_init(void);

void mtr_init(void)
{

    motor_fsp_init ();

    /* Execute reset event */
    g_motor_encoder0.p_api->reset (g_motor_encoder0.p_ctrl);

    g_motor_encoder0.p_api->run (g_motor_encoder0.p_ctrl);

    RM_MOTOR_CURRENT_Open(g_motor_current0.p_ctrl, g_motor_current0.p_cfg);
    RM_MOTOR_CURRENT_Run(g_motor_current0.p_ctrl);

}

void mtr_main(void)
{
    /* 1. Read the current raw electrical angle */
    RM_MOTOR_ENCODER_AngleGet(g_motor_encoder0.p_ctrl, &raw_angle);

    /* 2. Initialize tracking reference on first loop */
    if (first_run)
    {
        previous_raw_angle = raw_angle;
        continuous_angle_mech = 0.0f;
        error_integral = 0.0f;
        first_run = false;
        return;
    }

    /* 3. Calculate electrical step delta */
    float delta_elec = raw_angle - previous_raw_angle;

    /* 4. Unwrap electrical boundary jumps (-PI <-> +PI or 0 <-> 2*PI) */
    if (delta_elec > PI)
    {
        delta_elec -= (2.0f * PI);
    }
    else if (delta_elec < -PI)
    {
        delta_elec += (2.0f * PI);
    }

    /* 5. Convert electrical delta to true mechanical delta */
    float delta_mech = delta_elec / MOTOR_POLE_PAIRS;

    /* 6. Accumulate continuous mechanical angle */
    continuous_angle_mech += delta_mech;
    previous_raw_angle = raw_angle;

    /* 7. Calculate Error (Target position is 0.0 mechanical radians) */
    float error = 0.0f - continuous_angle_mech;

    /* 8. Proportional Term */
    float p_term = Kp * error;

    /* 9. Integral Term with Integration */
    error_integral += error * SAMPLE_TIME_S;
    float i_term = Ki * error_integral;

    /* 10. Derivative Term (Derivative on measurement to prevent kick) */
    // Velocity w = delta_mech / dt
    float velocity = delta_mech / SAMPLE_TIME_S;
    float d_term = -Kd * velocity;

    /* 11. Sum Controller Components */
    Iq = p_term + i_term + d_term;

    /* 12. Anti-Windup Clamping */
    if (Iq > max_current)
    {
        Iq = max_current;
        // Prevent integral windup when output saturates
        error_integral -= error * SAMPLE_TIME_S;
    }
    else if (Iq < -max_current)
    {
        Iq = -max_current;
        // Prevent integral windup when output saturates
        error_integral -= error * SAMPLE_TIME_S;
    }

    /* 13. Apply new quadrature current reference to FSP current control loop */
    RM_MOTOR_CURRENT_CurrentReferenceSet(g_motor_current0.p_ctrl, 0.0f, Iq);
}

/***********************************************************************************************************************
 * Function Name : motor_fsp_init
 * Description   : Initialize Motor FSP modules
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void motor_fsp_init(void)
{
    motor_speed_position_data_t temp_position_data;

    R_POEG_Open (g_poeg0.p_ctrl, g_poeg0.p_cfg);
    g_motor_encoder0.p_api->open (g_motor_encoder0.p_ctrl, g_motor_encoder0.p_cfg);
    g_elc.p_api->open (g_elc.p_ctrl, g_elc.p_cfg);
    g_elc.p_api->enable (g_elc.p_ctrl);

    g_user_motor_cfg = *(g_motor_encoder0_ctrl.p_cfg);
    g_user_motor_encoder_extended_cfg = *(motor_encoder_extended_cfg_t*) g_user_motor_cfg.p_extend;
    g_user_motor_cfg.p_extend = &g_user_motor_encoder_extended_cfg;
    g_motor_encoder0_ctrl.p_cfg = &g_user_motor_cfg;

 /*   g_user_motor_speed_cfg = *(g_motor_speed0_ctrl.p_cfg);
    g_user_motor_speed_extended_cfg = *(motor_speed_extended_cfg_t*) g_user_motor_speed_cfg.p_extend;
    g_user_motor_speed_cfg.p_extend = &g_user_motor_speed_extended_cfg;
    temp_position_data.e_step_mode = MOTOR_SPEED_STEP_DISABLE;
    temp_position_data.e_loop_mode = MOTOR_SPEED_LOOP_MODE_POSITION;
    temp_position_data.position_reference_degree = 0;
    g_motor_speed0.p_api->positionReferenceSet (g_motor_speed0.p_ctrl, &temp_position_data);
*/
    g_user_motor_position_cfg = *(g_motor_position0_ctrl.p_cfg);
    g_user_motor_position_extended_cfg = *(motor_position_extended_cfg_t*) g_user_motor_position_cfg.p_extend;
    g_user_motor_position_cfg.p_extend = &g_user_motor_position_extended_cfg;

    g_user_motor_current_cfg = *(g_motor_current0_ctrl.p_cfg);
    g_user_motor_current_extended_cfg = *(motor_current_extended_cfg_t*) g_user_motor_current_cfg.p_extend;
    g_user_motor_current_motor_parameter = *(g_user_motor_current_extended_cfg.p_motor_parameter);
    g_user_motor_current_design_parameter = *(g_user_motor_current_extended_cfg.p_design_parameter);
    g_user_motor_current_extended_cfg.p_motor_parameter = &g_user_motor_current_motor_parameter;
    g_user_motor_current_extended_cfg.p_design_parameter = &g_user_motor_current_design_parameter;
    g_user_motor_current_cfg.p_extend = &g_user_motor_current_extended_cfg;

    g_user_motor_angle_cfg = *(g_motor_sense_encoder0_ctrl.p_cfg);
    g_user_motor_sense_encoder_extended_cfg = *(motor_sense_encoder_extended_cfg_t*) g_user_motor_angle_cfg.p_extend;
    g_user_motor_angle_cfg.p_extend = &g_user_motor_sense_encoder_extended_cfg;
    g_motor_sense_encoder0.p_api->parameterUpdate (g_motor_sense_encoder0.p_ctrl, &g_user_motor_angle_cfg);

    g_user_motor_driver_cfg = *(g_motor_driver0_ctrl.p_cfg);
    g_user_motor_driver_extended_cfg = *(motor_driver_extended_cfg_t*) g_user_motor_driver_cfg.p_extend;
    g_user_motor_driver_cfg.p_extend = &g_user_motor_driver_extended_cfg;
} /* End of function motor_fsp_init */

void mtr_callback_encoder(motor_callback_args_t *p_args)
{
    if (MOTOR_CALLBACK_EVENT_CURRENT_FORWARD == p_args->event)
    {
        g_motor_encoder0.p_api->errorCheck (g_motor_encoder0.p_ctrl, &g_u2_chk_error);
        mtr_main();
        actual_iq_ref = g_motor_current0_ctrl.f_iq_ref;
        RM_MOTOR_ENCODER_AngleGet(g_motor_encoder0.p_ctrl, &raw_angle);

    }
}

/***********************************************************************************************************************
 * Function Name : g_poe_overcurrent
 * Description   : POEG2 Interrupt callback function
 * Arguments     : p_args - Callback argument
 * Return Value  : None
 ***********************************************************************************************************************/
void g_poe_overcurrent(poeg_callback_args_t *p_args)
{
    if (NULL != p_args)
    {
        R_POEG_Reset (g_poeg0.p_ctrl);
        g_motor_encoder0.p_api->errorSet (g_motor_encoder0.p_ctrl, MOTOR_ERROR_OVER_CURRENT_HW);
        g_u2_chk_error |= MOTOR_ERROR_OVER_CURRENT_HW;
    }
} /* End of function g_poe_overcurrent */

