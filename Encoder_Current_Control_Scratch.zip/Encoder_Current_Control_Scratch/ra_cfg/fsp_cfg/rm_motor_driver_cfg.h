/* generated configuration header file - do not edit */
#ifndef RM_MOTOR_DRIVER_CFG_H_
#define RM_MOTOR_DRIVER_CFG_H_
#ifdef __cplusplus
            extern "C" {
            #endif

#define MOTOR_DRIVER_CFG_PARAM_CHECKING_ENABLE   (BSP_CFG_PARAM_CHECKING_ENABLE)
#define MOTOR_DRIVER_CFG_ADC_B_SUPPORTED (0)

#ifdef __cplusplus
            }
            #endif
#endif /* RM_MOTOR_DRIVER_CFG_H_ */
