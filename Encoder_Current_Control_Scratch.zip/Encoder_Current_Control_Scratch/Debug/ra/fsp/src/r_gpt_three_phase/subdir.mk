################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/fsp/src/r_gpt_three_phase/r_gpt_three_phase.c 

C_DEPS += \
./ra/fsp/src/r_gpt_three_phase/r_gpt_three_phase.d 

OBJS += \
./ra/fsp/src/r_gpt_three_phase/r_gpt_three_phase.o 

SREC += \
Encoder_Current_Control_Scratch.srec 

MAP += \
Encoder_Current_Control_Scratch.map 


# Each subdirectory must supply rules for building sources it contributes
ra/fsp/src/r_gpt_three_phase/%.o: ../ra/fsp/src/r_gpt_three_phase/%.c
	$(file > $@.in,-mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CM4 -D_RA_ORDINAL=1 -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/src/main" -I"." -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_gen" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/src" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include" -std=c99 -Wno-stringop-overflow -Wno-format-truncation -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

