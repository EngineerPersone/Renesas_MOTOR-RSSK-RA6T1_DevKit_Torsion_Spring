ra_gen/main.o: ../ra_gen/main.c ../ra_gen/hal_data.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/bsp_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_common_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_version.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_gen/bsp_clock_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/ra6t1/bsp_mcu_info.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/ra6t1/bsp_elc.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/ra6t1/bsp_feature.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/board_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/board/ra6t1_rssk/board.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/board/ra6t1_rssk/board_init.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/board/ra6t1_rssk/board_leds.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_arm_exceptions.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_gen/vector_data.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/cmsis_compiler.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/cmsis_gcc.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA6T1AD.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/core_cm4.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/cmsis_version.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/cmsis_compiler.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/mpu_armv7.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_common.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_common_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_irq.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_io.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_clocks.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_security.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_features.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_common_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_delay.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h \
 ../ra_gen/common_data.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_elc.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/r_elc_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_elc_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/bsp_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_ioport.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_ioport_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/r_ioport_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_poeg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_poeg_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_gpt.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_timer_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_sense_encoder.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_angle_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/rm_motor_sense_encoder_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_gpt.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_gpt_three_phase.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_three_phase_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_timer_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_adc.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/r_adc_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_adc_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_elc_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_transfer_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_driver.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/rm_motor_driver_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_driver_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_adc_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_three_phase_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_current.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_current_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_driver_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_angle_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_position.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_position_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/rm_motor_position_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_agt.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/r_agt_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_speed.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_speed_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_position_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/rm_motor_speed_cfg.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_encoder.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_speed_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_current_api.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_speed.h \
 C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_current.h
../ra_gen/hal_data.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/bsp_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_common_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_version.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_gen/bsp_clock_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/ra6t1/bsp_mcu_info.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/ra6t1/bsp_elc.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/ra6t1/bsp_feature.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/board_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/board/ra6t1_rssk/board.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/board/ra6t1_rssk/board_init.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/board/ra6t1_rssk/board_leds.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_arm_exceptions.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_gen/vector_data.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/cmsis_compiler.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/cmsis_gcc.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA6T1AD.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/core_cm4.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/cmsis_version.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/cmsis_compiler.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include/mpu_armv7.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_common.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_common_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_irq.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_io.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_clocks.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_security.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_features.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/fsp_common_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_delay.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h:
../ra_gen/common_data.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_elc.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/r_elc_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_elc_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/bsp_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_ioport.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_ioport_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/r_ioport_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_poeg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_poeg_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_gpt.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_timer_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_sense_encoder.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_angle_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/rm_motor_sense_encoder_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_gpt.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_gpt_three_phase.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_three_phase_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_timer_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_adc.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/r_adc_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_adc_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_elc_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_transfer_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_driver.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/rm_motor_driver_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_driver_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_adc_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/r_three_phase_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_current.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_current_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_driver_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_angle_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_position.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_position_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/rm_motor_position_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/r_agt.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/r_agt_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_speed.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_speed_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_position_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/rm_motor_speed_cfg.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_encoder.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_speed_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api/rm_motor_current_api.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_speed.h:
C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances/rm_motor_current.h:
