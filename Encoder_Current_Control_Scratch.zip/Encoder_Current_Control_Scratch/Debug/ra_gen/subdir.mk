################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra_gen/common_data.c \
../ra_gen/elc_data.c \
../ra_gen/hal_data.c \
../ra_gen/main.c \
../ra_gen/pin_data.c \
../ra_gen/vector_data.c 

C_DEPS += \
./ra_gen/common_data.d \
./ra_gen/elc_data.d \
./ra_gen/hal_data.d \
./ra_gen/main.d \
./ra_gen/pin_data.d \
./ra_gen/vector_data.d 

OBJS += \
./ra_gen/common_data.o \
./ra_gen/elc_data.o \
./ra_gen/hal_data.o \
./ra_gen/main.o \
./ra_gen/pin_data.o \
./ra_gen/vector_data.o 

SREC += \
Encoder_Current_Control_Scratch.srec 

MAP += \
Encoder_Current_Control_Scratch.map 


# Each subdirectory must supply rules for building sources it contributes
ra_gen/%.o: ../ra_gen/%.c
	$(file > $@.in,-mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CM4 -D_RA_ORDINAL=1 -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg/bsp" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/src/main" -I"." -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_gen" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra_cfg/fsp_cfg" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/src" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/api" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/fsp/inc/instances" -I"C:/Users/danie/e2_studio/workspace/Encoder_Current_Control_Scratch/ra/arm/CMSIS_5/CMSIS/Core/Include" -std=c99 -Wno-stringop-overflow -Wno-format-truncation -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

