################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_position

