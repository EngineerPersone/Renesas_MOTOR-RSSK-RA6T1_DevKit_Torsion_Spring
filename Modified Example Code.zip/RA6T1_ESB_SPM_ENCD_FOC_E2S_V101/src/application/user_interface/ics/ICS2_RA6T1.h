











#ifndef __ICS2_RA6T1_H__
#define __ICS2_RA6T1_H__

#define ICS_SCI0_P101_P100     (0x00U)
#define ICS_SCI4_P205_P206     (0x40U)
#define ICS_SCI9_P109_P110     (0x90U)

void     ics2_init(uint8_t port, uint8_t speed, uint8_t mode);
void     ics2_watchpoint(void);
uint32_t ics2_version(void);

#endif /* __ICS2_RA6T1_H__ */
