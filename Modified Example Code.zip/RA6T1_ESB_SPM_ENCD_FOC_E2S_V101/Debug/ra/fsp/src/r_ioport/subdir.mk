################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/fsp/src/r_ioport/r_ioport.c 

C_DEPS += \
./ra/fsp/src/r_ioport/r_ioport.d 

OBJS += \
./ra/fsp/src/r_ioport/r_ioport.o 

SREC += \
RA6T1_ESB_SPM_ENCD_FOC_E2S_V101.srec 

MAP += \
RA6T1_ESB_SPM_ENCD_FOC_E2S_V101.map 


# Each subdirectory must supply rules for building sources it contributes
ra/fsp/src/r_ioport/%.o: ../ra/fsp/src/r_ioport/%.c
	$(file > $@.in,-mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CM4 -D_RA_ORDINAL=1 -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/src" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/src/application/main" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/src/application" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/src/application/user_interface" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/src" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/src/application/user_interface/ics" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/ra/fsp/inc" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/ra/fsp/inc/api" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/ra/fsp/inc/instances" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/ra/arm/CMSIS_5/CMSIS/Core/Include" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/ra_gen" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/ra_cfg/fsp_cfg/bsp" -I"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/ra_cfg/fsp_cfg" -I"." -include"C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/src/application/user_interface/ics/r_mtr_ics.h" -std=c99 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

