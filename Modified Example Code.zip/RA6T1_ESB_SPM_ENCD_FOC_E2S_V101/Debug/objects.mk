################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Users/danie/Desktop/Renesas/RA6T1_ESB_SPM_ENCD_FOC_E2S_V101/src/application/user_interface/ics/ICS2_RA6T1.o

LIBS := -lrm_motor_current -lrm_motor_speed -lrm_motor_position

