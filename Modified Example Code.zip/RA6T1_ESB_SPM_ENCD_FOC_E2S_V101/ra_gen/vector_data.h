/* generated vector header file - do not edit */
#ifndef VECTOR_DATA_H
#define VECTOR_DATA_H
#ifdef __cplusplus
        extern "C" {
        #endif
/* Number of interrupts allocated */
#ifndef VECTOR_DATA_IRQ_COUNT
#define VECTOR_DATA_IRQ_COUNT    (5)
#endif
/* ISR prototypes */
void agt_int_isr(void);
void adc_scan_end_isr(void);
void gpt_capture_a_isr(void);
void poeg_event_isr(void);
void gpt_counter_overflow_isr(void);

/* Vector table allocations */
#define VECTOR_NUMBER_AGT0_INT ((IRQn_Type) 0) /* AGT0 INT (AGT interrupt) */
#define AGT0_INT_IRQn          ((IRQn_Type) 0) /* AGT0 INT (AGT interrupt) */
#define VECTOR_NUMBER_ADC0_SCAN_END ((IRQn_Type) 1) /* ADC0 SCAN END (A/D scan end interrupt) */
#define ADC0_SCAN_END_IRQn          ((IRQn_Type) 1) /* ADC0 SCAN END (A/D scan end interrupt) */
#define VECTOR_NUMBER_GPT8_CAPTURE_COMPARE_A ((IRQn_Type) 2) /* GPT8 CAPTURE COMPARE A (Compare match A) */
#define GPT8_CAPTURE_COMPARE_A_IRQn          ((IRQn_Type) 2) /* GPT8 CAPTURE COMPARE A (Compare match A) */
#define VECTOR_NUMBER_POEG2_EVENT ((IRQn_Type) 3) /* POEG2 EVENT (Port Output disable interrupt C) */
#define POEG2_EVENT_IRQn          ((IRQn_Type) 3) /* POEG2 EVENT (Port Output disable interrupt C) */
#define VECTOR_NUMBER_GPT1_COUNTER_OVERFLOW ((IRQn_Type) 4) /* GPT1 COUNTER OVERFLOW (Overflow) */
#define GPT1_COUNTER_OVERFLOW_IRQn          ((IRQn_Type) 4) /* GPT1 COUNTER OVERFLOW (Overflow) */
#ifdef __cplusplus
        }
        #endif
#endif /* VECTOR_DATA_H */
