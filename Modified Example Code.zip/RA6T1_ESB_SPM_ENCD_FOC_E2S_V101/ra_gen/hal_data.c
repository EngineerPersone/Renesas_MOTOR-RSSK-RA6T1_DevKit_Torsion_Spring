/* generated HAL source file - do not edit */
#include "hal_data.h"

/* Macros to tie dynamic ELC links to ADC_TRIGGER_SYNC_ELC option in adc_trigger_t. */
#define ADC_TRIGGER_ADC0        ADC_TRIGGER_SYNC_ELC
#define ADC_TRIGGER_ADC0_B      ADC_TRIGGER_SYNC_ELC
#define ADC_TRIGGER_ADC1        ADC_TRIGGER_SYNC_ELC
#define ADC_TRIGGER_ADC1_B      ADC_TRIGGER_SYNC_ELC

gpt_instance_ctrl_t g_timer6_ctrl;
#if 0
const gpt_extended_pwm_cfg_t g_timer6_pwm_extend =
{
    .trough_ipl          = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT1_COUNTER_UNDERFLOW)
    .trough_irq          = VECTOR_NUMBER_GPT1_COUNTER_UNDERFLOW,
#else
    .trough_irq          = FSP_INVALID_VECTOR,
#endif
    .poeg_link           = GPT_POEG_LINK_POEG0,
    .output_disable      = (gpt_output_disable_t) ( GPT_OUTPUT_DISABLE_NONE),
    .adc_trigger         = (gpt_adc_trigger_t) ( GPT_ADC_TRIGGER_NONE),
    .dead_time_count_up  = 0,
    .dead_time_count_down = 0,
    .adc_a_compare_match = 0,
    .adc_b_compare_match = 0,
    .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
    .interrupt_skip_count  = GPT_INTERRUPT_SKIP_COUNT_0,
    .interrupt_skip_adc    = GPT_INTERRUPT_SKIP_ADC_NONE,
    .gtioca_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
    .gtiocb_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
};
#endif
const gpt_extended_cfg_t g_timer6_extend =
        { .gtioca =
        { .output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
          .gtiocb =
          { .output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
          .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .count_up_source = (gpt_source_t) (GPT_SOURCE_NONE), .count_down_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED), .capture_b_ipl =
                  (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT1_CAPTURE_COMPARE_A)
    .capture_a_irq       = VECTOR_NUMBER_GPT1_CAPTURE_COMPARE_A,
#else
          .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT1_CAPTURE_COMPARE_B)
    .capture_b_irq       = VECTOR_NUMBER_GPT1_CAPTURE_COMPARE_B,
#else
          .capture_b_irq = FSP_INVALID_VECTOR,
#endif
          .capture_filter_gtioca = GPT_CAPTURE_FILTER_NONE,
          .capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 0
    .p_pwm_cfg                   = &g_timer6_pwm_extend,
#else
          .p_pwm_cfg = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) false,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
    .gtior_setting.gtior_b.gtiob  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) false,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
          .gtior_setting.gtior = 0U,
#endif
        };
const timer_cfg_t g_timer6_cfg =
{ .mode = TIMER_MODE_PERIODIC,
/* Actual period: 0.01 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0x124f80,
  .duty_cycle_counts = 0x927c0, .source_div = (timer_source_div_t) 0, .channel = 1, .p_callback = Speed_Set_Callback,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = &NULL,
#endif
  .p_extend = &g_timer6_extend,
  .cycle_end_ipl = (10),
#if defined(VECTOR_NUMBER_GPT1_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT1_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer6 =
{ .p_ctrl = &g_timer6_ctrl, .p_cfg = &g_timer6_cfg, .p_api = &g_timer_on_gpt };
poeg_instance_ctrl_t g_poeg0_ctrl;
const poeg_cfg_t g_poeg0_cfg =
{ .trigger = (poeg_trigger_t) (POEG_TRIGGER_PIN | POEG_TRIGGER_SOFTWARE),
  .polarity = POEG_GTETRG_POLARITY_ACTIVE_LOW,
  .noise_filter = POEG_GTETRG_NOISE_FILTER_DISABLED,
  .channel = 2,
  .ipl = (0),
  .p_callback = g_poe_overcurrent,
  .p_context = NULL,
#if defined(VECTOR_NUMBER_POEG2_EVENT)
    .irq       = VECTOR_NUMBER_POEG2_EVENT,
#else
  .irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const poeg_instance_t g_poeg0 =
{ .p_ctrl = &g_poeg0_ctrl, .p_cfg = &g_poeg0_cfg, .p_api = &g_poeg_on_poeg };
gpt_instance_ctrl_t g_timer5_ctrl;
#if 0
const gpt_extended_pwm_cfg_t g_timer5_pwm_extend =
{
    .trough_ipl          = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT1_COUNTER_UNDERFLOW)
    .trough_irq          = VECTOR_NUMBER_GPT1_COUNTER_UNDERFLOW,
#else
    .trough_irq          = FSP_INVALID_VECTOR,
#endif
    .poeg_link           = GPT_POEG_LINK_POEG0,
    .output_disable      = (gpt_output_disable_t) ( GPT_OUTPUT_DISABLE_NONE),
    .adc_trigger         = (gpt_adc_trigger_t) ( GPT_ADC_TRIGGER_NONE),
    .dead_time_count_up  = 0,
    .dead_time_count_down = 0,
    .adc_a_compare_match = 0,
    .adc_b_compare_match = 0,
    .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
    .interrupt_skip_count  = GPT_INTERRUPT_SKIP_COUNT_0,
    .interrupt_skip_adc    = GPT_INTERRUPT_SKIP_ADC_NONE,
    .gtioca_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
    .gtiocb_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
};
#endif
const gpt_extended_cfg_t g_timer5_extend =
        { .gtioca =
        { .output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
          .gtiocb =
          { .output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
          .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .count_up_source = (gpt_source_t) (GPT_SOURCE_NONE), .count_down_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED), .capture_b_ipl =
                  (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT1_CAPTURE_COMPARE_A)
    .capture_a_irq       = VECTOR_NUMBER_GPT1_CAPTURE_COMPARE_A,
#else
          .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT1_CAPTURE_COMPARE_B)
    .capture_b_irq       = VECTOR_NUMBER_GPT1_CAPTURE_COMPARE_B,
#else
          .capture_b_irq = FSP_INVALID_VECTOR,
#endif
          .capture_filter_gtioca = GPT_CAPTURE_FILTER_NONE,
          .capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 0
    .p_pwm_cfg                   = &g_timer5_pwm_extend,
#else
          .p_pwm_cfg = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) false,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
    .gtior_setting.gtior_b.gtiob  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) false,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
          .gtior_setting.gtior = 0U,
#endif
        };
const timer_cfg_t g_timer5_cfg =
{ .mode = TIMER_MODE_PERIODIC,
/* Actual period: 35.791394125 seconds. Actual duty: 49.99999998835847%. */.period_counts = (uint32_t) 0xffffffff,
  .duty_cycle_counts = 0x7fffffff, .source_div = (timer_source_div_t) 0, .channel = 1, .p_callback = NULL,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = &NULL,
#endif
  .p_extend = &g_timer5_extend,
  .cycle_end_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT1_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT1_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer5 =
{ .p_ctrl = &g_timer5_ctrl, .p_cfg = &g_timer5_cfg, .p_api = &g_timer_on_gpt };
gpt_instance_ctrl_t g_timer4_ctrl;
#if 0
const gpt_extended_pwm_cfg_t g_timer4_pwm_extend =
{
    .trough_ipl          = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT8_COUNTER_UNDERFLOW)
    .trough_irq          = VECTOR_NUMBER_GPT8_COUNTER_UNDERFLOW,
#else
    .trough_irq          = FSP_INVALID_VECTOR,
#endif
    .poeg_link           = GPT_POEG_LINK_POEG0,
    .output_disable      = (gpt_output_disable_t) ( GPT_OUTPUT_DISABLE_NONE),
    .adc_trigger         = (gpt_adc_trigger_t) ( GPT_ADC_TRIGGER_NONE),
    .dead_time_count_up  = 0,
    .dead_time_count_down = 0,
    .adc_a_compare_match = 0,
    .adc_b_compare_match = 0,
    .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
    .interrupt_skip_count  = GPT_INTERRUPT_SKIP_COUNT_0,
    .interrupt_skip_adc    = GPT_INTERRUPT_SKIP_ADC_NONE,
    .gtioca_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
    .gtiocb_disable_setting = GPT_GTIOC_DISABLE_PROHIBITED,
};
#endif
const gpt_extended_cfg_t g_timer4_extend =
{ .gtioca =
{ .output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
  .gtiocb =
  { .output_enabled = false, .stop_level = GPT_PIN_LEVEL_LOW },
  .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
          (gpt_source_t) (GPT_SOURCE_NONE),
  .count_up_source = (gpt_source_t) (
          GPT_SOURCE_GTIOCA_RISING_WHILE_GTIOCB_HIGH | GPT_SOURCE_GTIOCA_FALLING_WHILE_GTIOCB_LOW
                  | GPT_SOURCE_GTIOCB_RISING_WHILE_GTIOCA_LOW | GPT_SOURCE_GTIOCB_FALLING_WHILE_GTIOCA_HIGH
                  | GPT_SOURCE_NONE),
  .count_down_source = (gpt_source_t) (
          GPT_SOURCE_GTIOCA_RISING_WHILE_GTIOCB_LOW | GPT_SOURCE_GTIOCA_FALLING_WHILE_GTIOCB_HIGH
                  | GPT_SOURCE_GTIOCB_RISING_WHILE_GTIOCA_HIGH | GPT_SOURCE_GTIOCB_FALLING_WHILE_GTIOCA_LOW
                  | GPT_SOURCE_NONE),
  .capture_a_source = (gpt_source_t) (
          GPT_SOURCE_GTIOCA_RISING_WHILE_GTIOCB_LOW | GPT_SOURCE_GTIOCA_RISING_WHILE_GTIOCB_HIGH
                  | GPT_SOURCE_GTIOCA_FALLING_WHILE_GTIOCB_LOW | GPT_SOURCE_GTIOCA_FALLING_WHILE_GTIOCB_HIGH
                  | GPT_SOURCE_GTIOCB_RISING_WHILE_GTIOCA_LOW | GPT_SOURCE_GTIOCB_RISING_WHILE_GTIOCA_HIGH
                  | GPT_SOURCE_GTIOCB_FALLING_WHILE_GTIOCA_LOW | GPT_SOURCE_GTIOCB_FALLING_WHILE_GTIOCA_HIGH
                  | GPT_SOURCE_NONE),
  .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (3), .capture_b_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT8_CAPTURE_COMPARE_A)
    .capture_a_irq       = VECTOR_NUMBER_GPT8_CAPTURE_COMPARE_A,
#else
  .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT8_CAPTURE_COMPARE_B)
    .capture_b_irq       = VECTOR_NUMBER_GPT8_CAPTURE_COMPARE_B,
#else
  .capture_b_irq = FSP_INVALID_VECTOR,
#endif
  .capture_filter_gtioca = GPT_CAPTURE_FILTER_PCLKD_DIV_4,
  .capture_filter_gtiocb = GPT_CAPTURE_FILTER_PCLKD_DIV_4,
#if 0
    .p_pwm_cfg                   = &g_timer4_pwm_extend,
#else
  .p_pwm_cfg = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) false,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_PCLKD_DIV_4 & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_PCLKD_DIV_4 >> 1U),
    .gtior_setting.gtior_b.gtiob  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_LOW,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) false,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_PROHIBITED,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_PCLKD_DIV_4 & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_PCLKD_DIV_4 >> 1U),
#else
  .gtior_setting.gtior = 0U,
#endif
        };
const timer_cfg_t g_timer4_cfg =
{ .mode = TIMER_MODE_PERIODIC,
/* Actual period: 0.139810125 seconds. Actual duty: 49.999997019767584%. */.period_counts = (uint32_t) 0xffffff,
  .duty_cycle_counts = 0x7fffff, .source_div = (timer_source_div_t) 0, .channel = 8, .p_callback =
          rm_motor_sense_encoder_interrupt,
  /** If NULL then do not add & */
#if defined(g_motor_sense_encoder0)
    .p_context           = g_motor_sense_encoder0,
#else
  .p_context = &g_motor_sense_encoder0,
#endif
  .p_extend = &g_timer4_extend,
  .cycle_end_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT8_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT8_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer4 =
{ .p_ctrl = &g_timer4_ctrl, .p_cfg = &g_timer4_cfg, .p_api = &g_timer_on_gpt };
motor_sense_encoder_instance_ctrl_t g_motor_sense_encoder0_ctrl;
const motor_sense_encoder_extended_cfg_t g_motor_sense_encoder0_extend =
{ .loop_mode = MOTOR_SENSE_ENCODER_LOOP_SPEED,
  .f_current_ctrl_period = 1.0F / (20.0F * 1000.0F),
  .f_speed_ctrl_period = 0.0005F,
  .encoder_config.f_carrier_frequency = 20.0F,
  .encoder_config.u1_interrupt_decimation = 0U,
  .encoder_config.u2_cpr = 4000,
  .encoder_config.u2_angle_adjust_time = 512U,
  .encoder_config.u4_zero_speed_count = 20000000U,
  .encoder_config.f_occupancy_time = 0.8F,
  .encoder_config.f_carrier_time = 0.00004F,
  .encoder_config.f_process_time = 0.000004F,
  .encoder_config.u2_highspeed_change_margin_rpm = 150U,
  .encoder_config.f_highspeed_lpf_parameter = 0.1F,
  .encoder_config.u1_position_speed_change_counts = 8U,
  .st_motor_params.u2_mtr_pp = 2,
  .st_motor_params.f4_mtr_r = 8.5F,
  .st_motor_params.f4_mtr_ld = 0.0045F,
  .st_motor_params.f4_mtr_lq = 0.0045F,
  .st_motor_params.f4_mtr_m = 0.02159F,
  .st_motor_params.f4_mtr_j = 0.0000028F,
  .p_timer_instance = &g_timer5,
  .p_input_capture_instance = &g_timer4, };

const motor_angle_cfg_t g_motor_sense_encoder0_cfg =
{ .p_context = NULL, .p_extend = &g_motor_sense_encoder0_extend, };

/* Instance structure to use Motor Angle module. */
const motor_angle_instance_t g_motor_sense_encoder0 =
        { .p_ctrl = &g_motor_sense_encoder0_ctrl, .p_cfg = &g_motor_sense_encoder0_cfg, .p_api =
                  &g_motor_angle_on_motor_encoder };
gpt_instance_ctrl_t g_timer2_ctrl;
#if 1
const gpt_extended_pwm_cfg_t g_timer2_pwm_extend =
{ .trough_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT3_COUNTER_UNDERFLOW)
    .trough_irq          = VECTOR_NUMBER_GPT3_COUNTER_UNDERFLOW,
#else
  .trough_irq = FSP_INVALID_VECTOR,
#endif
  .poeg_link = GPT_POEG_LINK_POEG2,
  .output_disable = (gpt_output_disable_t) (GPT_OUTPUT_DISABLE_NONE),
  .adc_trigger = (gpt_adc_trigger_t) (GPT_ADC_TRIGGER_NONE),
  .dead_time_count_up = 240,
  .dead_time_count_down = 240,
  .adc_a_compare_match = 0,
  .adc_b_compare_match = 0,
  .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
  .interrupt_skip_count = GPT_INTERRUPT_SKIP_COUNT_0,
  .interrupt_skip_adc = GPT_INTERRUPT_SKIP_ADC_NONE,
  .gtioca_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z,
  .gtiocb_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z, };
#endif
const gpt_extended_cfg_t g_timer2_extend =
        { .gtioca =
        { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
          .gtiocb =
          { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
          .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .count_up_source = (gpt_source_t) (GPT_SOURCE_NONE), .count_down_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED), .capture_b_ipl =
                  (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_A)
    .capture_a_irq       = VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_A,
#else
          .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_B)
    .capture_b_irq       = VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_B,
#else
          .capture_b_irq = FSP_INVALID_VECTOR,
#endif
          .capture_filter_gtioca = GPT_CAPTURE_FILTER_NONE,
          .capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 1
          .p_pwm_cfg = &g_timer2_pwm_extend,
#else
    .p_pwm_cfg                   = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_HIGH,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) true,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
    .gtior_setting.gtior_b.gtiob  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_HIGH,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) true,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
          .gtior_setting.gtior = 0U,
#endif
        };
const timer_cfg_t g_timer2_cfg =
{ .mode = TIMER_MODE_TRIANGLE_WAVE_SYMMETRIC_PWM,
/* Actual period: 0.00005 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0xbb8,
  .duty_cycle_counts = 0x5dc, .source_div = (timer_source_div_t) 0, .channel = 3, .p_callback = NULL,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = &NULL,
#endif
  .p_extend = &g_timer2_extend,
  .cycle_end_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT3_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT3_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer2 =
{ .p_ctrl = &g_timer2_ctrl, .p_cfg = &g_timer2_cfg, .p_api = &g_timer_on_gpt };
gpt_instance_ctrl_t g_timer1_ctrl;
#if 1
const gpt_extended_pwm_cfg_t g_timer1_pwm_extend =
{ .trough_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT2_COUNTER_UNDERFLOW)
    .trough_irq          = VECTOR_NUMBER_GPT2_COUNTER_UNDERFLOW,
#else
  .trough_irq = FSP_INVALID_VECTOR,
#endif
  .poeg_link = GPT_POEG_LINK_POEG2,
  .output_disable = (gpt_output_disable_t) (GPT_OUTPUT_DISABLE_NONE),
  .adc_trigger = (gpt_adc_trigger_t) (GPT_ADC_TRIGGER_NONE),
  .dead_time_count_up = 240,
  .dead_time_count_down = 240,
  .adc_a_compare_match = 0,
  .adc_b_compare_match = 0,
  .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
  .interrupt_skip_count = GPT_INTERRUPT_SKIP_COUNT_0,
  .interrupt_skip_adc = GPT_INTERRUPT_SKIP_ADC_NONE,
  .gtioca_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z,
  .gtiocb_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z, };
#endif
const gpt_extended_cfg_t g_timer1_extend =
        { .gtioca =
        { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
          .gtiocb =
          { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
          .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .count_up_source = (gpt_source_t) (GPT_SOURCE_NONE), .count_down_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED), .capture_b_ipl =
                  (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_A)
    .capture_a_irq       = VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_A,
#else
          .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_B)
    .capture_b_irq       = VECTOR_NUMBER_GPT2_CAPTURE_COMPARE_B,
#else
          .capture_b_irq = FSP_INVALID_VECTOR,
#endif
          .capture_filter_gtioca = GPT_CAPTURE_FILTER_NONE,
          .capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 1
          .p_pwm_cfg = &g_timer1_pwm_extend,
#else
    .p_pwm_cfg                   = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_HIGH,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) true,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
    .gtior_setting.gtior_b.gtiob  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_HIGH,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) true,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
          .gtior_setting.gtior = 0U,
#endif
        };
const timer_cfg_t g_timer1_cfg =
{ .mode = TIMER_MODE_TRIANGLE_WAVE_SYMMETRIC_PWM,
/* Actual period: 0.00005 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0xbb8,
  .duty_cycle_counts = 0x5dc, .source_div = (timer_source_div_t) 0, .channel = 2, .p_callback = NULL,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = &NULL,
#endif
  .p_extend = &g_timer1_extend,
  .cycle_end_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT2_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT2_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer1 =
{ .p_ctrl = &g_timer1_ctrl, .p_cfg = &g_timer1_cfg, .p_api = &g_timer_on_gpt };
gpt_instance_ctrl_t g_timer0_ctrl;
#if 1
const gpt_extended_pwm_cfg_t g_timer0_pwm_extend =
{ .trough_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT0_COUNTER_UNDERFLOW)
    .trough_irq          = VECTOR_NUMBER_GPT0_COUNTER_UNDERFLOW,
#else
  .trough_irq = FSP_INVALID_VECTOR,
#endif
  .poeg_link = GPT_POEG_LINK_POEG2,
  .output_disable = (gpt_output_disable_t) (GPT_OUTPUT_DISABLE_NONE),
  .adc_trigger = (gpt_adc_trigger_t) (GPT_ADC_TRIGGER_NONE),
  .dead_time_count_up = 240,
  .dead_time_count_down = 240,
  .adc_a_compare_match = 0,
  .adc_b_compare_match = 0,
  .interrupt_skip_source = GPT_INTERRUPT_SKIP_SOURCE_NONE,
  .interrupt_skip_count = GPT_INTERRUPT_SKIP_COUNT_0,
  .interrupt_skip_adc = GPT_INTERRUPT_SKIP_ADC_NONE,
  .gtioca_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z,
  .gtiocb_disable_setting = GPT_GTIOC_DISABLE_SET_HI_Z, };
#endif
const gpt_extended_cfg_t g_timer0_extend =
        { .gtioca =
        { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
          .gtiocb =
          { .output_enabled = true, .stop_level = GPT_PIN_LEVEL_HIGH },
          .start_source = (gpt_source_t) (GPT_SOURCE_NONE), .stop_source = (gpt_source_t) (GPT_SOURCE_NONE), .clear_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .count_up_source = (gpt_source_t) (GPT_SOURCE_NONE), .count_down_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_source =
                  (gpt_source_t) (GPT_SOURCE_NONE),
          .capture_b_source = (gpt_source_t) (GPT_SOURCE_NONE), .capture_a_ipl = (BSP_IRQ_DISABLED), .capture_b_ipl =
                  (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_A)
    .capture_a_irq       = VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_A,
#else
          .capture_a_irq = FSP_INVALID_VECTOR,
#endif
#if defined(VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_B)
    .capture_b_irq       = VECTOR_NUMBER_GPT0_CAPTURE_COMPARE_B,
#else
          .capture_b_irq = FSP_INVALID_VECTOR,
#endif
          .capture_filter_gtioca = GPT_CAPTURE_FILTER_NONE,
          .capture_filter_gtiocb = GPT_CAPTURE_FILTER_NONE,
#if 1
          .p_pwm_cfg = &g_timer0_pwm_extend,
#else
    .p_pwm_cfg                   = NULL,
#endif
#if 0
    .gtior_setting.gtior_b.gtioa  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.oadflt = (uint32_t) GPT_PIN_LEVEL_HIGH,
    .gtior_setting.gtior_b.oahld  = 0U,
    .gtior_setting.gtior_b.oae    = (uint32_t) true,
    .gtior_setting.gtior_b.oadf   = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z,
    .gtior_setting.gtior_b.nfaen  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsa  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
    .gtior_setting.gtior_b.gtiob  = (0U << 4U) | (0U << 2U) | (0U << 0U),
    .gtior_setting.gtior_b.obdflt = (uint32_t) GPT_PIN_LEVEL_HIGH,
    .gtior_setting.gtior_b.obhld  = 0U,
    .gtior_setting.gtior_b.obe    = (uint32_t) true,
    .gtior_setting.gtior_b.obdf   = (uint32_t) GPT_GTIOC_DISABLE_SET_HI_Z,
    .gtior_setting.gtior_b.nfben  = ((uint32_t) GPT_CAPTURE_FILTER_NONE & 1U),
    .gtior_setting.gtior_b.nfcsb  = ((uint32_t) GPT_CAPTURE_FILTER_NONE >> 1U),
#else
          .gtior_setting.gtior = 0U,
#endif
        };
const timer_cfg_t g_timer0_cfg =
{ .mode = TIMER_MODE_TRIANGLE_WAVE_SYMMETRIC_PWM,
/* Actual period: 0.00005 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0xbb8,
  .duty_cycle_counts = 0x5dc, .source_div = (timer_source_div_t) 0, .channel = 0, .p_callback = NULL,
  /** If NULL then do not add & */
#if defined(NULL)
    .p_context           = NULL,
#else
  .p_context = &NULL,
#endif
  .p_extend = &g_timer0_extend,
  .cycle_end_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_GPT0_COUNTER_OVERFLOW)
    .cycle_end_irq       = VECTOR_NUMBER_GPT0_COUNTER_OVERFLOW,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer0 =
{ .p_ctrl = &g_timer0_ctrl, .p_cfg = &g_timer0_cfg, .p_api = &g_timer_on_gpt };
gpt_three_phase_instance_ctrl_t g_three_phase0_ctrl;
const three_phase_cfg_t g_three_phase0_cfg =
{ .buffer_mode = (THREE_PHASE_BUFFER_MODE_SINGLE), .p_timer_instance =
{ &g_timer0, &g_timer1, &g_timer2 },
  .callback_ch = THREE_PHASE_CHANNEL_U, .channel_mask = (1 << 0) | (1 << 2) | (1 << 3), .p_context = NULL, .p_extend =
          NULL, };
/* Instance structure to use this module. */
const three_phase_instance_t g_three_phase0 =
{ .p_ctrl = &g_three_phase0_ctrl, .p_cfg = &g_three_phase0_cfg, .p_api = &g_gpt_three_phase_on_gpt_three_phase };
adc_instance_ctrl_t g_adc0_ctrl;
const adc_extended_cfg_t g_adc0_cfg_extend =
{ .add_average_count = ADC_ADD_OFF,
  .clearing = ADC_CLEAR_AFTER_READ_OFF,
  .trigger_group_b = ADC_TRIGGER_SYNC_ELC,
  .double_trigger_mode = ADC_DOUBLE_TRIGGER_DISABLED,
  .adc_vref_control = ADC_VREF_CONTROL_VREFH,
  .enable_adbuf = 0,
#if defined(VECTOR_NUMBER_ADC0_WINDOW_A)
    .window_a_irq        = VECTOR_NUMBER_ADC0_WINDOW_A,
#else
  .window_a_irq = FSP_INVALID_VECTOR,
#endif
  .window_a_ipl = (BSP_IRQ_DISABLED),
#if defined(VECTOR_NUMBER_ADC0_WINDOW_B)
    .window_b_irq      = VECTOR_NUMBER_ADC0_WINDOW_B,
#else
  .window_b_irq = FSP_INVALID_VECTOR,
#endif
  .window_b_ipl = (BSP_IRQ_DISABLED), };
const adc_cfg_t g_adc0_cfg =
{ .unit = 0, .mode = ADC_MODE_SINGLE_SCAN, .resolution = ADC_RESOLUTION_12_BIT, .alignment =
          (adc_alignment_t) ADC_ALIGNMENT_RIGHT,
  .trigger = ADC_TRIGGER_ADC0, .p_callback = rm_motor_driver_cyclic,
  /** If NULL then do not add & */
#if defined(g_motor_driver0)
    .p_context           = g_motor_driver0,
#else
  .p_context = &g_motor_driver0,
#endif
  .p_extend = &g_adc0_cfg_extend,
#if defined(VECTOR_NUMBER_ADC0_SCAN_END)
    .scan_end_irq        = VECTOR_NUMBER_ADC0_SCAN_END,
#else
  .scan_end_irq = FSP_INVALID_VECTOR,
#endif
  .scan_end_ipl = (5),
#if defined(VECTOR_NUMBER_ADC0_SCAN_END_B)
    .scan_end_b_irq      = VECTOR_NUMBER_ADC0_SCAN_END_B,
#else
  .scan_end_b_irq = FSP_INVALID_VECTOR,
#endif
  .scan_end_b_ipl = (BSP_IRQ_DISABLED), };
#if ((0) | (0))
const adc_window_cfg_t g_adc0_window_cfg =
{
    .compare_mask        =  0,
    .compare_mode_mask   =  0,
    .compare_cfg         = (0) | (0) | (0) | (ADC_COMPARE_CFG_EVENT_OUTPUT_OR),
    .compare_ref_low     = 0,
    .compare_ref_high    = 0,
    .compare_b_channel   = (ADC_WINDOW_B_CHANNEL_0),
    .compare_b_mode      = (ADC_WINDOW_B_MODE_LESS_THAN_OR_OUTSIDE),
    .compare_b_ref_low   = 0,
    .compare_b_ref_high  = 0,
};
#endif
const adc_channel_cfg_t g_adc0_channel_cfg =
{ .scan_mask = ADC_MASK_CHANNEL_0 | ADC_MASK_CHANNEL_2 | ADC_MASK_CHANNEL_5 | ADC_MASK_CHANNEL_17 | 0,
  .scan_mask_group_b = 0,
  .priority_group_a = ADC_GROUP_A_PRIORITY_OFF,
  .add_mask = 0,
  .sample_hold_mask = ADC_MASK_CHANNEL_0 | ADC_MASK_CHANNEL_2 | 0,
  .sample_hold_states = 24,
#if ((0) | (0))
    .p_window_cfg        = (adc_window_cfg_t *) &g_adc0_window_cfg,
#else
  .p_window_cfg = NULL,
#endif
        };
/* Instance structure to use this module. */
const adc_instance_t g_adc0 =
{ .p_ctrl = &g_adc0_ctrl, .p_cfg = &g_adc0_cfg, .p_channel_cfg = &g_adc0_channel_cfg, .p_api = &g_adc_on_adc };
/* Motor Driver Configuration */
motor_driver_instance_ctrl_t g_motor_driver0_ctrl;

const motor_driver_extended_cfg_t g_motor_driver0_extend =
{ .u2_pwm_timer_freq = 120,
  .u2_pwm_carrier_freq = 1.0F / (50 / 1000.0F),
  .u2_deadtime = (240 / 120),
  .f_current_range = 27.5F,
  .f_vdc_range = 111.0F,
  .f_ad_resolution = 0xFFF,
  .f_ad_current_offset = 0x745,
  .f_ad_voltage_conversion = 0.66F,
  .u2_offset_calc_count = 500,
  .modulation_method = MOTOR_DRIVER_MODULATION_METHOD_SVPWM,
  .f_ad_current_adjust = 20.0F,
  .s4_difference_minimum = 300,
  .s4_adjust_adc_delay = 240,
  .mod_param.f4_vdc = 24.0F,
  .mod_param.f4_1_div_vdc = 1.0F / 24.0F,
  .mod_param.f4_voltage_error_ratio = (240 / 120) / 50,
  .mod_param.f4_max_duty = 0.9375F,
  .mod_param.f4_min_duty = (240 / 120) / 50,
  .mod_param.f4_neutral_duty = 0.5F,
  .mod_param.u1_sat_flag = 0U, };

const motor_driver_cfg_t g_motor_driver0_cfg =
{ .p_adc_instance = &g_adc0,
  .iu_ad_ch = 0,
  .iv_ad_ch = 1,
  .iw_ad_ch = 2,
  .vdc_ad_ch = 5,
  .sin_ad_ch = 27,
  .cos_ad_ch = 28,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == RA_NOT_DEFINED)
  .p_adc2_instance = NULL,
#else
  .p_adc2_instance = &RA_NOT_DEFINED,
#endif
#undef RA_NOT_DEFINED
  .shunt = MOTOR_DRIVER_SHUNT_TYPE_2_SHUNT,
  .p_three_phase_instance = &g_three_phase0,
  .p_callback = rm_motor_current_cyclic,
  .p_context = &g_motor_current0,
  .p_extend = &g_motor_driver0_extend, };

/* Instance structure to use Motor Driver module. */
const motor_driver_instance_t g_motor_driver0 =
{ .p_ctrl = &g_motor_driver0_ctrl, .p_cfg = &g_motor_driver0_cfg, .p_api = &g_motor_driver_on_motor_driver, };
/* Motor Current Configuration */
motor_current_instance_ctrl_t g_motor_current0_ctrl;

motor_current_design_parameter_t g_motor_current0_design =
{ .f_current_omega = 300.0F, .f_current_zeta = 1.0F, };

motor_current_motor_parameter_t g_motor_current0_motor =
{ .u2_mtr_pp = 2, .f4_mtr_r = 8.5F, .f4_mtr_ld = 0.0045F, .f4_mtr_lq = 0.0045F, .f4_mtr_m = 0.02159F, .f4_mtr_j =
          0.0000028F, };

const motor_current_extended_cfg_t g_motor_current0_extend =
{ .f_comp_v[0] = 0.672F,
  .f_comp_v[1] = 0.945F,
  .f_comp_v[2] = 1.054F,
  .f_comp_v[3] = 1.109F,
  .f_comp_v[4] = 1.192F,
  .f_comp_i[0] = 0.013F,
  .f_comp_i[1] = 0.049F,
  .f_comp_i[2] = 0.080F,
  .f_comp_i[3] = 0.184F,
  .f_comp_i[4] = 0.751F,
  .vcomp_enable = MOTOR_CURRENT_VOLTAGE_COMPENSATION_SELECT_ENABLE,
  .f_current_ctrl_period = (0 + 1.0F) / 20.0F,
  .f_ilimit = 24.0F / 2.0F,
  .p_motor_parameter = &g_motor_current0_motor,
  .p_design_parameter = &g_motor_current0_design,
  .u1_control_type = MOTOR_CURRENT_CONTROL_TYPE_ENCODER,
  .shunt = MOTOR_CURRENT_SHUNT_TYPE_2_SHUNT,
  .u1_sample_delay_comp_enable = MOTOR_CURRENT_SAMPLE_DELAY_COMPENSATION_ENABLE, };

const motor_current_cfg_t g_motor_current0_cfg =
{ .p_motor_driver_instance = &g_motor_driver0, .p_motor_angle_instance = &g_motor_sense_encoder0, .p_callback =
          rm_motor_encoder_current_callback,
  .p_context = &g_motor_encoder0, .p_extend = &g_motor_current0_extend, };

/* Instance structure to use motor current control module. */
const motor_current_instance_t g_motor_current0 =
{ .p_ctrl = &g_motor_current0_ctrl, .p_cfg = &g_motor_current0_cfg, .p_api = &g_motor_current_on_motor_current, };
/* Motor Position Control Configuration */
motor_position_instance_ctrl_t g_motor_position0_ctrl;

const motor_position_extended_cfg_t g_motor_position0_extend =
{ .u2_pos_dead_band = 1U,
  .u2_pos_band_limit = 3U,
  .f_speed_ff_ratio = 0.8F,
  .f_encd_angle_diff = 2.0F * 3.14159265359F / 4000.0F,
  .f_pos_omega = 10.0F,
  .f_speed_ctrl_period = 0.0005F,
  .ipd_lpf = MOTOR_POSITION_IPD_LPF_DISABLE,
  .st_ipd_design.f4_ipd_pos_kp_ratio = 0.3F,
  .st_ipd_design.f4_ipd_pos_ff_ratio = 0.0F,
  .st_ipd_design.f4_ipd_speed_k_ratio = 2.0F,
  .st_ipd_design.f4_ipd_err_limit_1 = 10.0F,
  .st_ipd_design.f4_ipd_err_limit_2 = 0.2F,
  .st_ipd_design.f4_ipd_lpf_omega = 500.0F,
  .st_ipd_design.f4_ipd_lpf_zeta = 1.0F,
  .st_profiling_set.u2_interval_time = 400U,
  .st_profiling_set.f4_accel_time = 0.3F,
  .st_profiling_set.f4_max_accel = 11077.904F,
  .st_profiling_set.f4_accel_max_speed = 2201.0F,
  .st_profiling_set.f4_timer_update_step = 0.0005F,
  .st_motor.u2_mtr_pp = 2,
  .st_motor.f4_mtr_r = 8.5F,
  .st_motor.f4_mtr_ld = 0.0045F,
  .st_motor.f4_mtr_lq = 0.0045F,
  .st_motor.f4_mtr_m = 0.02159F,
  .st_motor.f4_mtr_j = 0.0000028F, };

const motor_position_cfg_t g_motor_position0_cfg =
{ .p_context = NULL, .p_extend = &g_motor_position0_extend, };

/* Instance structure to use motor position module. */
const motor_position_instance_t g_motor_position0 =
{ .p_ctrl = &g_motor_position0_ctrl, .p_cfg = &g_motor_position0_cfg, .p_api = &g_motor_position_on_motor_position, };
agt_instance_ctrl_t g_timer3_ctrl;
const agt_extended_cfg_t g_timer3_extend =
{ .count_source = AGT_CLOCK_PCLKB,
  .agto = AGT_PIN_CFG_DISABLED,
  .agtoab_settings_b.agtoa = AGT_PIN_CFG_DISABLED,
  .agtoab_settings_b.agtob = AGT_PIN_CFG_DISABLED,
  .measurement_mode = AGT_MEASURE_DISABLED,
  .agtio_filter = AGT_AGTIO_FILTER_NONE,
  .enable_pin = AGT_ENABLE_PIN_NOT_USED,
  .trigger_edge = AGT_TRIGGER_EDGE_RISING, };
const timer_cfg_t g_timer3_cfg =
{ .mode = TIMER_MODE_PERIODIC,
/* Actual period: 0.0005 seconds. Actual duty: 50%. */.period_counts = (uint32_t) 0x7530,
  .duty_cycle_counts = 0x3a98, .source_div = (timer_source_div_t) 0, .channel = 0, .p_callback = rm_motor_speed_cyclic,
  /** If NULL then do not add & */
#if defined(g_motor_speed0)
    .p_context           = g_motor_speed0,
#else
  .p_context = &g_motor_speed0,
#endif
  .p_extend = &g_timer3_extend,
  .cycle_end_ipl = (10),
#if defined(VECTOR_NUMBER_AGT0_INT)
    .cycle_end_irq       = VECTOR_NUMBER_AGT0_INT,
#else
  .cycle_end_irq = FSP_INVALID_VECTOR,
#endif
        };
/* Instance structure to use this module. */
const timer_instance_t g_timer3 =
{ .p_ctrl = &g_timer3_ctrl, .p_cfg = &g_timer3_cfg, .p_api = &g_timer_on_agt };
/* Motor Speed Configuration */
motor_speed_instance_ctrl_t g_motor_speed0_ctrl;

const motor_speed_extended_cfg_t g_motor_speed0_extend =
{ .f_speed_ctrl_period = 0.0005F,
  .f_limit_speed_change = 0.5F * 2,
  .f_max_speed_rad = 2650 * 2,
  .f_omega_t = 10.0F,
  .f_id_up_speed_rad = 500 * 2,
  .f_iq_limit = 0.42F,
  .f_ol_fb_speed_limit_rate = 0.20F,
  .u1_openloop_damping = MOTOR_SPEED_OPENLOOP_DAMPING_ENABLE,
  .u1_flux_weakening = MOTOR_SPEED_FLUX_WEAKEN_DISABLE,
  .u1_less_switch = MOTOR_SPEED_LESS_SWITCH_DISABLE,
  .u1_observer_swtich = MOTOR_SPEED_OBSERVER_SWITCH_ENABLE,
  .u1_ctrl_method = MOTOR_SPEED_METHOD_PID,
  .ol_param.f4_ol_id_up_step = 0.3F / 256.0F,
  .ol_param.f4_ol_id_down_step = 0.3F / 50.0F,
  .ol_param.f4_ol_iq_down_step_ratio = 1.0F,
  .ol_param.f4_ol_id_ref = 0.3F,
  .ol_param.f4_id_down_speed_rad = 600 * 2,
  .ol_param.f4_id_up_speed_rad = 500 * 2,
  .ol_param.f4_opl2less_sw_time = 0.025F,
  .ol_param.f4_switch_phase_err_rad = 10,
  .ol_sub_param.f_damp_comp_gain = 0.0F,
  .ol_sub_param.f_fb_speed_limit_rate = 0.0F,
  .d_param.f_speed_omega = 30.0F,
  .d_param.f_speed_zeta = 1.0F,
  .d_param.f_ed_hpf_omega = 2.5F,
  .d_param.f_ol_damping_zeta = 1.0F,
  .d_param.f_phase_err_lpf_cut_freq = 10.0F,
  .d_param.f_observer_omega = 200.0F,
  .d_param.f_observer_zeta = 1.0F,
  .control_type = MOTOR_SPEED_CONTROL_TYPE_ENCODER,
  .mtr_param.u2_mtr_pp = 2,
  .mtr_param.f4_mtr_r = 8.5F,
  .mtr_param.f4_mtr_ld = 0.0045F,
  .mtr_param.f4_mtr_lq = 0.0045F,
  .mtr_param.f4_mtr_m = 0.02159F,
  .mtr_param.f4_mtr_j = 0.0000028F, };

const motor_speed_cfg_t g_motor_speed0_cfg =
{ .st_input = &(g_motor_encoder0_ctrl.st_speed_input),
  .st_output = &(g_motor_encoder0_ctrl.st_speed_output),
  .p_callback = rm_motor_encoder_speed_callback,
  .p_context = &g_motor_encoder0,
  .p_timer_instance = &g_timer3,
#define RA_NOT_DEFINED (1)
#if (RA_NOT_DEFINED == g_motor_position0)
  .p_position_instance = NULL,
#else
  .p_position_instance = &g_motor_position0,
#endif
#undef RA_NOT_DEFINED
  .p_extend = &g_motor_speed0_extend, };

/* Instance structure to use motor speed module. */
const motor_speed_instance_t g_motor_speed0 =
{ .p_ctrl = &g_motor_speed0_ctrl, .p_cfg = &g_motor_speed0_cfg, .p_api = &g_motor_speed_on_motor_speed, };
/* Motor encoder control configuration */
motor_encoder_instance_ctrl_t g_motor_encoder0_ctrl;

const motor_encoder_extended_cfg_t g_motor_encoder0_extend =
        { .f_overcurrent_limit = 0.42F,
          .f_overvoltage_limit = 28.0F,
          .f_overspeed_limit = 3000.0F,
          .f_lowvoltage_limit = 14.0F, };

const motor_cfg_t g_motor_encoder0_cfg =
{ .p_callback = mtr_callback_encoder,
  .p_context = NULL,
  .p_motor_speed_instance = &g_motor_speed0,
  .p_motor_current_instance = &g_motor_current0,
  .p_extend = &g_motor_encoder0_extend, };

/* Instance structure to use motor encoder control module. */
const motor_instance_t g_motor_encoder0 =
{ .p_ctrl = &g_motor_encoder0_ctrl, .p_cfg = &g_motor_encoder0_cfg, .p_api = &g_motor_on_encoder, };
void g_hal_init(void)
{
    g_common_init ();
}
