/* generated vector source file - do not edit */
#include "bsp_api.h"
/* Do not build these data structures if no interrupts are currently allocated because IAR will have build errors. */
#if VECTOR_DATA_IRQ_COUNT > 0
        BSP_DONT_REMOVE const fsp_vector_t g_vector_table[BSP_ICU_VECTOR_MAX_ENTRIES] BSP_PLACE_IN_SECTION(BSP_SECTION_APPLICATION_VECTORS) =
        {
                        [0] = agt_int_isr, /* AGT0 INT (AGT interrupt) */
            [1] = adc_scan_end_isr, /* ADC0 SCAN END (A/D scan end interrupt) */
            [2] = gpt_capture_a_isr, /* GPT8 CAPTURE COMPARE A (Compare match A) */
            [3] = poeg_event_isr, /* POEG2 EVENT (Port Output disable interrupt C) */
            [4] = gpt_counter_overflow_isr, /* GPT1 COUNTER OVERFLOW (Overflow) */
        };
        const bsp_interrupt_event_t g_interrupt_event_link_select[BSP_ICU_VECTOR_MAX_ENTRIES] =
        {
            [0] = BSP_PRV_IELS_ENUM(EVENT_AGT0_INT), /* AGT0 INT (AGT interrupt) */
            [1] = BSP_PRV_IELS_ENUM(EVENT_ADC0_SCAN_END), /* ADC0 SCAN END (A/D scan end interrupt) */
            [2] = BSP_PRV_IELS_ENUM(EVENT_GPT8_CAPTURE_COMPARE_A), /* GPT8 CAPTURE COMPARE A (Compare match A) */
            [3] = BSP_PRV_IELS_ENUM(EVENT_POEG2_EVENT), /* POEG2 EVENT (Port Output disable interrupt C) */
            [4] = BSP_PRV_IELS_ENUM(EVENT_GPT1_COUNTER_OVERFLOW), /* GPT1 COUNTER OVERFLOW (Overflow) */
        };
        #endif
